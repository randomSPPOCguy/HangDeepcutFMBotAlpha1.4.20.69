# Original Hang.fm Bot - Reference Package for ChatGPT

## 📦 **WHAT'S IN THIS PACKAGE**

This folder contains the **WORKING ORIGINAL BOT** for comparison with the modular version.

### **Files Included:**

1. **`hang-fm-bot-ORIGINAL.js`** (9,728 lines)
   - Complete, working, monolithic bot
   - All AI features functional
   - All mood tracking working
   - All commands working

2. **`ORIGINAL-BOT-MAP.md`**
   - Detailed line-by-line map of the original bot
   - Section breakdown
   - Method descriptions
   - Critical flow diagrams

3. **`MODULAR-VS-ORIGINAL-COMPARISON.md`**
   - Side-by-side comparison of original vs modular
   - Identifies exact differences
   - Shows message flow in both versions
   - Checklist for verifying modular bot

4. **`package.json`**
   - Dependencies for the original bot

5. **`hang-fm-config.env.example`**
   - Example configuration file

---

## 🎯 **HOW TO USE THIS FOR DEBUGGING**

### **For ChatGPT:**

1. **Read `MODULAR-VS-ORIGINAL-COMPARISON.md` FIRST**
   - This has side-by-side code comparisons
   - Focus on the "AI Keyword Trigger" section

2. **Check `ORIGINAL-BOT-MAP.md`**
   - Find the exact line numbers for any feature
   - Understand how the original bot is structured

3. **Search `hang-fm-bot-ORIGINAL.js`**
   - Use line numbers from the map
   - Compare with modular bot implementation

---

## 🔑 **KEY DIFFERENCES SUMMARY**

| Feature | Original Bot | Modular Bot Location |
|---------|--------------|----------------------|
| **Message Polling** | Lines 5121-5220 | `CometChatManager.js` |
| **Keyword Detection** | Lines 3563-3706 | `EventHandler.js` |
| **AI Generation** | Lines 4642-4921 | `AIManager.js` |
| **Mood Tracking** | Lines 928-994 | `AIManager.js` |
| **Content Filtering** | Lines 5566-6066 | `ContentFilter.js` |
| **Commands** | Lines 3707-4581 | `CommandHandler.js` |

---

## 🚀 **QUICK TEST COMMANDS**

### Test Original Bot:
```powershell
cd "C:\Users\markq\Ultimate bot project\hangfm-bot"
node hang-fm-bot.js
```

### Test Modular Bot:
```powershell
cd "C:\Users\markq\Ultimate bot project\hangfm-bot-modular"
node hang-fm-bot.js
```

---

## ⚙️ **CONFIGURATION**

Both bots use the same environment variables from `hang-fm-config.env`:

```env
# CometChat
COMETCHAT_APP_ID=2520000000000000
COMETCHAT_REGION=us
COMETCHAT_AUTH=your-auth-token

# Hang.fm
BOT_USER_TOKEN=your-bot-token
USER_ID=62acab2b-8f82-4c48-9c1a-7b35adf54047
ROOM_ID=a75a3a53-533a-4ced-90c8-dd569ce8ba04

# AI
AI_PROVIDER=gemini
GEMINI_API_KEY=your-gemini-key
OPENAI_API_KEY=your-openai-key
HUGGINGFACE_API_KEY=your-hf-key
```

---

## 📊 **WHAT WORKS IN ORIGINAL BOT**

✅ **AI Keyword Triggers:**
- Keywords: `bot`, `b0t`, `bot2`, `b0t2`, `@bot2`, `sppoc`, `smashing pumpkins`
- Case-insensitive substring matching
- Triggers AI response every time (no duplicate suppression bug)

✅ **Message Deduplication:**
- Uses `message.id` ONLY
- No text-based deduplication

✅ **AI Providers:**
- Gemini (primary)
- OpenAI (fallback)
- HuggingFace (fallback)

✅ **Mood Tracking:**
- 3-tier system (neutral, positive, negative)
- Updates on each interaction
- Used in AI personality prompts

✅ **Conversation Memory:**
- Stores last 5 messages per user
- Passed to AI for context

✅ **Commands:**
- `/help`, `/stats`, `/ai`, `/grant`, etc.
- All functional

---

## 🐛 **KNOWN ISSUES (Already Fixed in Modular)**

❌ **No mood decay:** Original doesn't reset mood after inactivity

❌ **No pre-AI content filtering:** Original checks after AI generation

❌ **No 5-tier mood system:** Original only has 3 tiers

✅ **All these are IMPROVEMENTS in the modular bot!**

---

## 📝 **NOTES FOR CHATGPT**

- The original bot is **9,728 lines** in one file
- It's too large to read all at once (25MB limit)
- Use the **line numbers** from `ORIGINAL-BOT-MAP.md` to jump to specific sections
- Focus on the **message flow** in `MODULAR-VS-ORIGINAL-COMPARISON.md`

**This should give you everything you need to debug the modular bot!** 🚀

