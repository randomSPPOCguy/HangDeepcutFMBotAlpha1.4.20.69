# Modular Bot vs Original Bot - Side-by-Side Comparison

## 🔍 **CHATGPT: Use this to find what's different!**

---

## 📂 **FILE MAPPING**

| **Original Bot (Monolithic)**          | **Modular Bot (Separated)**                          |
|----------------------------------------|------------------------------------------------------|
| `hangfm-bot/hang-fm-bot.js` (9728 lines) | Split into multiple modules:                        |
| Lines 11-244: Constructor + Config     | → `modules/core/Config.js`                           |
| Lines 501-787: Socket connection       | → `modules/connection/SocketManager.js`              |
| Lines 3079-5270: CometChat             | → `modules/connection/CometChatManager.js`           |
| Lines 3563-3706: Message processing    | → `modules/handlers/EventHandler.js`                 |
| Lines 3707-4581: Commands              | → `modules/handlers/CommandHandler.js`               |
| Lines 4642-5122: AI generation         | → `modules/ai/AIManager.js`                          |
| Lines 4922-5122: AI providers          | → `modules/ai/GeminiProvider.js` etc.                |
| Lines 928-994: Sentiment tracking      | → `modules/ai/AIManager.js` (updateUserSentiment)    |
| Lines 5566-6066: Content filtering     | → `modules/features/ContentFilter.js`                |
| Lines 1809-2917: Music selection       | → `modules/music/MusicSelector.js`                   |
| Lines 3448-3562: Spam protection       | → `modules/utils/SpamProtection.js`                  |

---

## 🎯 **CRITICAL FLOW: AI KEYWORD TRIGGER**

### **ORIGINAL BOT (WORKING ✅)**

#### **Step 1: CometChat Polling**
**File:** `hangfm-bot/hang-fm-bot.js`  
**Line:** 5121

```javascript
async startMessagePolling() {
  this.pollingInterval = setInterval(async () => {
    try {
      const limit = 10;
      const messagesRequest = new CometChat.MessagesRequestBuilder()
        .setLimit(limit)
        .setGUID(this.roomId)
        .build();
      
      const messages = await messagesRequest.fetchPrevious();
      
      messages.forEach(message => {
        const messageKey = message.id; // ✅ ONLY MESSAGE ID
        
        if (!this.lastMessageIds.has(messageKey)) {
          this.lastMessageIds.set(messageKey, Date.now());
          this.handleCometChatMessage(message); // ← Routes to processUserMessage
        }
      });
    } catch (error) {
      console.error('❌ Message polling error:', error);
    }
  }, 2000); // Poll every 2 seconds
}
```

#### **Step 2: Handle Message**
**File:** `hangfm-bot/hang-fm-bot.js`  
**Line:** 3243

```javascript
async handleCometChatMessage(data) {
  const text = data.text;
  const senderId = data.sender.uid;
  const senderName = data.sender.name;
  const messageId = data.id;
  
  // Skip bot's own messages
  if (senderId === this.userId) return;
  
  // Process the message
  await this.processUserMessage(text, senderId, senderName, messageId);
}
```

#### **Step 3: Check Keywords & Call AI**
**File:** `hangfm-bot/hang-fm-bot.js`  
**Line:** 3563

```javascript
async processUserMessage(text, senderId, senderName, messageId = null) {
  // Spam check
  if (!await this.checkSpamProtection(senderId)) return;
  
  // Check for keywords
  const lowerText = text.toLowerCase();
  const hasKeyword = this.keywordTriggers.some(keyword => 
    lowerText.includes(keyword.toLowerCase())
  );
  
  if (hasKeyword && this.aiChatEnabled) {
    console.log(`🎯 AI keyword detected: ${text}`);
    
    // Update sentiment
    await this.updateUserSentiment(senderId, text);
    
    // Generate AI response
    const aiResponse = await this.generateAIResponse(text, senderId, senderName);
    
    if (aiResponse) {
      console.log(`🤖 AI response: ${aiResponse}`);
      await this.sendChat(aiResponse);
    }
  }
  
  // Check for commands
  if (text.startsWith('/')) {
    await this.handleCommand(text, senderId, senderName);
  }
}
```

#### **Step 4: Generate AI Response**
**File:** `hangfm-bot/hang-fm-bot.js`  
**Line:** 4642

```javascript
async generateAIResponse(message, userId, userName) {
  // Get user sentiment
  const sentiment = this.userSentiment.get(userId) || { 
    sentiment: 'neutral', 
    interactions: 0 
  };
  
  // Build personality based on mood
  let personalityPrompt = '';
  if (sentiment.sentiment === 'positive') {
    personalityPrompt = `Be friendly and enthusiastic! The user ${userName} has been nice to you.`;
  } else if (sentiment.sentiment === 'negative') {
    personalityPrompt = `Be sarcastic and sassy. ${userName} has been rude, so give it back.`;
  } else {
    personalityPrompt = 'Be neutral and informative.';
  }
  
  // Get conversation history
  const conversation = this.userConversations.get(userId) || [];
  const recentMessages = conversation.slice(-5);
  
  // Build full prompt
  const contextPrompt = `
Current song: ${this.currentSong ? this.currentSong.artistName + ' - ' + this.currentSong.trackName : 'None'}
Room: Alternative HipHop/Rock/Metal
${personalityPrompt}

Recent conversation:
${recentMessages.map(m => `${m.role}: ${m.content}`).join('\n')}

User: ${message}
`;
  
  // Call AI provider
  let response;
  if (this.currentProvider === 'gemini') {
    response = await this.callGemini(contextPrompt);
  } else if (this.currentProvider === 'openai') {
    response = await this.callOpenAI(contextPrompt);
  } else {
    response = await this.callHuggingFace(contextPrompt);
  }
  
  // Store in conversation memory
  conversation.push({ role: 'user', content: message });
  conversation.push({ role: 'assistant', content: response });
  this.userConversations.set(userId, conversation);
  
  return response;
}
```

---

### **MODULAR BOT (NEEDS VERIFICATION ⚠️)**

#### **Step 1: CometChat Polling**
**File:** `hangfm-bot-modular/modules/connection/CometChatManager.js`  
**Line:** ~110

```javascript
async pollMessages() {
  setInterval(async () => {
    try {
      const messagesRequest = new CometChat.MessagesRequestBuilder()
        .setLimit(10)
        .setGUID(this.roomId)
        .build();
      
      const messages = await messagesRequest.fetchPrevious();
      
      messages.forEach(message => {
        const messageKey = `${message.id}`; // ✅ FIXED (was using text too)
        
        if (!this.processedMessages.has(messageKey)) {
          this.processedMessages.add(messageKey);
          
          // Emit message event
          if (this.bot?.handlers?.event?.onChatMessage) {
            this.bot.handlers.event.onChatMessage(message);
          }
        }
      });
    } catch (error) {
      this.logger.error('Message polling error:', error);
    }
  }, 2000);
}
```

#### **Step 2: Handle Message**
**File:** `hangfm-bot-modular/modules/handlers/EventHandler.js`  
**Line:** ~20

```javascript
async onChatMessage(message) {
  const text = message.text;
  const senderId = message.sender.uid;
  const senderName = message.sender.name;
  
  // Skip bot's own messages
  if (senderId === this.bot.config.userId) return;
  
  // Check for keywords
  const lowerText = text.toLowerCase();
  const hasKeyword = this.keywordTriggers.some(kw => lowerText.includes(kw));
  
  if (hasKeyword) {
    this.logger.log(`🎯 AI keyword detected: ${text}`);
    
    // Check spam
    if (!await this.bot.spam.checkAI(senderId)) {
      this.logger.warn(`⛔ Spam limit reached for user ${senderId}`);
      return;
    }
    
    // Content filtering (BEFORE AI)
    // ... link checks, hate speech checks ...
    
    // Generate AI response
    const response = await this.bot.ai.generateResponse(
      text, 
      senderId, 
      senderName,
      this.bot.socket.getCurrentSong(),
      this.bot.socket.getState()
    );
    
    if (response) {
      this.logger.log(`🤖 AI response: ${response}`);
      await this.bot.chat.sendMessage(this.roomId, response);
    }
  }
  
  // Handle commands
  if (text.startsWith('/')) {
    await this.bot.handlers.command.handle(text, senderId, senderName);
  }
}
```

#### **Step 3: Generate AI Response**
**File:** `hangfm-bot-modular/modules/ai/AIManager.js`  
**Line:** ~80

```javascript
async generateResponse(text, userId, userName, currentSong, roomState) {
  // Update sentiment
  await this.updateUserSentiment(userId, text);
  
  // Get sentiment
  const sentiment = this.userSentiment.get(userId) || {
    mood: 'neutral',
    consecutivePositive: 0,
    consecutiveNegative: 0
  };
  
  // Build personality based on 5-tier mood
  let personalityPrompt = '';
  switch (sentiment.mood) {
    case 'enthusiastic':
      personalityPrompt = `Be extra friendly and playful! User ${userName} has been consistently nice.`;
      break;
    case 'positive':
      personalityPrompt = 'Be friendly and helpful.';
      break;
    case 'hostile':
      personalityPrompt = `This user keeps insulting you. Be blunt and sarcastic.`;
      break;
    case 'annoyed':
      personalityPrompt = 'Be moderately sarcastic.';
      break;
    default:
      personalityPrompt = 'Be neutral and informative.';
  }
  
  // Get conversation history
  const conversation = this.conversations.get(userId) || [];
  const recentMessages = conversation.slice(-5);
  
  // Build context
  const context = {
    personalityPrompt,
    conversation: recentMessages,
    currentSong,
    roomState
  };
  
  // Call provider
  let response;
  const provider = this.getActiveProvider();
  response = await provider.generateResponse(text, context);
  
  // Store in memory
  conversation.push({ role: 'user', content: text });
  conversation.push({ role: 'assistant', content: response });
  this.conversations.set(userId, conversation);
  
  return response;
}
```

---

## ⚠️ **POTENTIAL ISSUES IN MODULAR BOT**

### **1. Event Wiring**
**CHECK:** Is `onChatMessage` in EventHandler properly connected to CometChat polling?

**Original:**
```javascript
// CometChatManager calls handler directly
this.handleCometChatMessage(message);
```

**Modular:**
```javascript
// CometChatManager emits event
this.bot.handlers.event.onChatMessage(message);
```

**❓ VERIFY:** Is `this.bot.handlers.event` properly initialized in `hang-fm-bot.js`?

---

### **2. Keyword Triggers**
**CHECK:** Are keywords loaded from config?

**Original:**
```javascript
this.keywordTriggers = ['bot', 'b0t', 'bot2', 'b0t2', '@bot2', 'sppoc', 'smashing pumpkins'];
```

**Modular:**
```javascript
// In EventHandler.js
this.keywordTriggers = config.keywordTriggers || ['bot', 'b0t', 'bot2', ...];
```

**❓ VERIFY:** Does `Config.js` load `keywordTriggers` from env or default?

---

### **3. AI Provider Selection**
**CHECK:** Does AIManager properly route to Gemini/OpenAI/HuggingFace?

**Original:**
```javascript
if (this.currentProvider === 'gemini') {
  response = await this.callGemini(prompt);
}
```

**Modular:**
```javascript
const provider = this.getActiveProvider(); // Returns GeminiProvider instance
response = await provider.generateResponse(text, context);
```

**❓ VERIFY:** Is `getActiveProvider()` returning the correct provider based on `AI_PROVIDER` env var?

---

### **4. Mood Decay**
**CHECK:** Does mood reset after 30 minutes of inactivity?

**Original:**
- No automatic decay (only resets on new interaction)

**Modular:**
- Implements 30-minute decay in `updateUserSentiment()`

**✅ ENHANCEMENT:** Modular is better here!

---

### **5. Content Filtering Order**
**CHECK:** Are links/hate speech checked BEFORE calling AI?

**Original:**
```javascript
// processUserMessage checks keyword first, THEN filters
if (hasKeyword) {
  await generateAIResponse(); // No pre-filtering
}
```

**Modular:**
```javascript
// EventHandler filters BEFORE AI
if (hasKeyword) {
  // Check links
  if (linkMatch && !isSafe) return;
  
  // Check hate speech
  if (isHateful) return;
  
  // THEN generate AI response
  await this.bot.ai.generateResponse(...);
}
```

**✅ ENHANCEMENT:** Modular is safer!

---

## 🔧 **CHECKLIST FOR CHATGPT**

To verify the modular bot matches the original:

- [ ] **1. CometChat Polling**
  - Check `CometChatManager.pollMessages()` is running
  - Verify deduplication uses `message.id` only
  - Confirm messages route to `EventHandler.onChatMessage()`

- [ ] **2. Keyword Detection**
  - Check `EventHandler.js` has full keyword list
  - Verify case-insensitive substring matching
  - Confirm spam check happens BEFORE AI call

- [ ] **3. AI Response**
  - Check `AIManager.generateResponse()` is called with correct params
  - Verify provider routing (Gemini/OpenAI/HF)
  - Confirm mood/sentiment is included in prompt

- [ ] **4. Mood System**
  - Check `updateUserSentiment()` tracks positive/negative
  - Verify 5-tier mood system (neutral → enthusiastic/hostile)
  - Confirm 30-minute decay logic

- [ ] **5. Conversation Memory**
  - Check last 5 messages stored per user
  - Verify conversation passed to AI provider

- [ ] **6. Response Sending**
  - Check `CometChatManager.sendMessage()` works
  - Verify bot doesn't respond to its own messages

---

## 📊 **SUMMARY**

| Feature                    | Original Bot | Modular Bot | Status |
|----------------------------|--------------|-------------|--------|
| Keyword detection          | ✅           | ✅          | ✅ Fixed |
| Deduplication (message.id) | ✅           | ✅          | ✅ Fixed |
| AI providers               | ✅           | ✅          | ✅ Implemented |
| Mood tracking (3-tier)     | ✅           | ❌          | ⚠️ Upgraded to 5-tier |
| Mood decay (30 min)        | ❌           | ✅          | ✅ Enhancement |
| Conversation memory        | ✅           | ✅          | ✅ Implemented |
| Content filtering (pre-AI) | ❌           | ✅          | ✅ Enhancement |
| Link whitelisting          | ✅           | ✅          | ✅ Enhanced |
| Spam protection            | ✅           | ✅          | ✅ Implemented |

---

## 🚀 **NEXT STEPS**

1. **Test the modular bot** with keyword trigger "bot"
2. **Watch logs** for:
   - `🎯 AI keyword detected`
   - `🤖 AI response: ...`
3. **If silent**, check:
   - Is `EventHandler.onChatMessage()` being called?
   - Is `AIManager.generateResponse()` being called?
   - Is the provider returning a response?

**Use this comparison to find ANY missing pieces!**

