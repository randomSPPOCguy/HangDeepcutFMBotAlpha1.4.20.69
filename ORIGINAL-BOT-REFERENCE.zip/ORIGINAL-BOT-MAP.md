# Original Hang.fm Bot - Code Map for ChatGPT

**File:** `hangfm-bot/hang-fm-bot.js` (9,728 lines - monolithic)

This bot **WORKS PERFECTLY** with all AI, mood tracking, and features functional.

---

## 📁 FILE STRUCTURE OVERVIEW

The original bot is a **single class** (`HangFmBot`) with **~100 methods** organized as follows:

### **SECTION 1: Constructor & Configuration (Lines 11-244)**
- **Lines 11-244**: Class constructor
  - Environment variable loading (BOT_USER_TOKEN, COMETCHAT_AUTH, etc.)
  - AI configuration (Gemini, OpenAI, HuggingFace)
  - Keyword triggers: `['bot', 'b0t', 'bot2', 'b0t2', '@bot2', 'sppoc', 'smashing pumpkins']`
  - Spam protection setup
  - User sentiment tracking maps
  - Content filter system
  - Stats loading

### **SECTION 2: Connection Methods (Lines 501-787)**
- **Line 501**: `async connect()` - Main socket connection
  - Creates `SocketClient` from `ttfm-socket`
  - Registers all event handlers:
    - `statefulMessage` → routes to event-specific handlers
    - `playedSong` → `handlePlayedSong()`
    - `userJoined` → user greet logic
    - `userLeft` → cleanup logic
  - Calls `connectCometChat()` for chat connection

- **Line 788**: `async handleSocketChatMessage(message)` - Socket-based chat handler

### **SECTION 3: AI Response Generation (Lines 3563-4923)**

**KEY METHODS (This is where AI triggers work!):**

- **Line 3563**: `async processUserMessage(text, senderId, senderName, messageId)`
  - **THIS IS THE ENTRY POINT FOR ALL CHAT MESSAGES**
  - Checks if message contains keyword triggers
  - Calls `generateAIResponse()` if keyword found
  - Uses deduplication via `this.lastMessageIds`

- **Line 3707**: `async handleCommand(text, senderId, senderName)`
  - Routes to command handlers (/help, /stats, etc.)

- **Line 4642**: `async generateAIResponse(message, userId, userName)` ⭐ **CRITICAL**
  - Builds AI prompt with:
    - User sentiment/mood
    - Current song context
    - Conversation history
    - Room vibe
  - Routes to provider: `callGemini()` | `callOpenAI()` | `callHuggingFace()`
  - **Returns actual AI-generated text**

- **Line 4953**: `async callGemini(prompt)` - Gemini API call
  - Model: `gemini-1.5-flash-latest`
  - Temperature: 0.8
  - Max tokens: 300

- **Line 4922**: `async callOpenAI(prompt)` - OpenAI API call
  - Model: `gpt-4o-mini`
  - Temperature: 0.7
  - Max tokens: 300

- **Line 5023**: `async callHuggingFace(prompt)` - HuggingFace API call

### **SECTION 4: CometChat Integration (Lines 3079-3706)**

- **Line 3079**: `async connectCometChat()`
  - Initializes CometChat SDK
  - Calls `joinCometChatGroup()` to join room chat
  - Starts `startMessagePolling()` loop

- **Line 3243**: `async handleCometChatMessage(data)` ⭐ **KEY FOR MODULAR**
  - Receives chat messages from CometChat polling
  - Filters out bot's own messages
  - **Calls `processUserMessage(text, senderId, senderName, messageId)`**
  - This is where chat → AI flow starts

- **Line 5121**: `async startMessagePolling()`
  - **Polls CometChat every 2 seconds** for new messages
  - Deduplicates using `messageKey = message.id` (FIXED in original)
  - Passes each message to `handleCometChatMessage()`

### **SECTION 5: Mood & Sentiment (Lines 928-994)**

- **Line 928**: `async updateUserSentiment(userId, message)`
  - Tracks positive/negative word counts
  - Updates mood: `neutral` → `positive` → `negative`
  - Stores in `this.userSentiment` Map
  - Used by `generateAIResponse()` to adjust personality

### **SECTION 6: Content Filtering (Lines 5507-6066)**

- **Line 5566**: `async checkAndHandleLinks(text, senderId, senderName, messageId)`
  - Detects links in messages
  - Calls `checkLinkSafety()`

- **Line 5728**: `async checkLinkSafety(url, username)`
  - Whitelists: spotify.com, last.fm, youtube.com, etc.
  - Blocks suspicious domains

- **Line 5788**: `async detectHatefulContentQuick(message)`
  - Quick keyword check for slurs

- **Line 5801**: `async detectHatefulContentInChat(message)`
  - AI-based hate speech detection using Gemini

### **SECTION 7: Music Selection (Lines 1809-2917)**

- **Line 1809**: `async selectAndQueueSong(context)`
  - AI-powered song selection
  - Uses genre requests, room vibe, learned artists

- **Line 2709**: `async getSongsForArtist(artist)`
  - Searches Hang.fm catalog for artist's songs

### **SECTION 8: Commands (Lines 3832-4581)**

All command handlers: `/help`, `/stats`, `/ai`, `/grant`, etc.

### **SECTION 9: Socket Event Handlers (Lines 1164-1591)**

- **Line 1164**: `async handlePlayedSong(message)`
  - Triggered when a song starts
  - Updates `this.currentSong`
  - Triggers auto-upvote
  - May trigger AI song selection

---

## 🔑 **KEY DIFFERENCES FROM MODULAR BOT**

### **1. Message Flow (ORIGINAL BOT)**
```
CometChat Polling (line 5121)
   ↓
handleCometChatMessage (line 3243)
   ↓
processUserMessage (line 3563) ← checks keyword triggers
   ↓
generateAIResponse (line 4642) ← builds prompt with mood/context
   ↓
callGemini/OpenAI/HuggingFace (lines 4953/4922/5023)
   ↓
sendChat (line 5271) ← sends response to room
```

### **2. Keyword Trigger Check (ORIGINAL BOT)**
**File:** `hangfm-bot/hang-fm-bot.js`
**Line 3563** (processUserMessage):
```javascript
// Check if message contains keyword triggers
const lowerText = text.toLowerCase();
const hasKeyword = this.keywordTriggers.some(keyword => 
  lowerText.includes(keyword.toLowerCase())
);

if (hasKeyword && this.aiChatEnabled) {
  // Generate AI response
  const aiResponse = await this.generateAIResponse(text, senderId, senderName);
  if (aiResponse) {
    await this.sendChat(aiResponse);
  }
}
```

### **3. Deduplication (ORIGINAL BOT - FIXED)**
**File:** `hangfm-bot/hang-fm-bot.js`
**Line 5121** (startMessagePolling):
```javascript
async startMessagePolling() {
  setInterval(async () => {
    // ... fetch messages ...
    
    messages.forEach(message => {
      const messageKey = message.id; // ✅ USES ONLY MESSAGE ID
      
      if (!this.lastMessageIds.has(messageKey)) {
        this.lastMessageIds.set(messageKey, Date.now());
        this.handleCometChatMessage(message);
      }
    });
  }, 2000); // Poll every 2 seconds
}
```

### **4. Mood Integration (ORIGINAL BOT)**
**File:** `hangfm-bot/hang-fm-bot.js`
**Line 4642** (generateAIResponse):
```javascript
// Get user sentiment
const sentiment = this.userSentiment.get(userId) || { 
  sentiment: 'neutral', 
  interactions: 0 
};

// Build personality prompt based on mood
let personalityPrompt = '';
if (sentiment.sentiment === 'positive') {
  personalityPrompt = 'Be friendly and enthusiastic!';
} else if (sentiment.sentiment === 'negative') {
  personalityPrompt = 'Be sarcastic and sassy.';
} else {
  personalityPrompt = 'Be neutral and informative.';
}

// Add to AI prompt
const fullPrompt = `${personalityPrompt}\n\nUser: ${message}`;
```

---

## 📊 **COMPARISON: WHAT WORKS IN ORIGINAL**

✅ **Working in Original Bot:**
- AI keyword detection (`bot`, `b0t`, etc.)
- Gemini/OpenAI/HuggingFace providers
- Mood tracking per user
- Conversation memory (last 5 messages)
- Link safety checks
- Hate speech detection
- Message deduplication (using message.id only)
- CometChat polling every 2 seconds
- Auto-upvote on song play
- Command handling (/help, /stats, etc.)

---

## 🎯 **FOR CHATGPT: WHERE TO LOOK**

**To fix the modular bot AI responses, compare these specific sections:**

1. **Message Polling Flow:**
   - Original: Lines 5121-5220 (`startMessagePolling`)
   - Modular: `CometChatManager.js` polling logic

2. **Keyword Detection:**
   - Original: Lines 3563-3706 (`processUserMessage`)
   - Modular: `EventHandler.js` keyword check

3. **AI Response Generation:**
   - Original: Lines 4642-4921 (`generateAIResponse`)
   - Modular: `AIManager.js` generateResponse

4. **Deduplication Logic:**
   - Original: Line 5140 (`messageKey = message.id`)
   - Modular: `CometChatManager.js` line 122

5. **Mood System:**
   - Original: Lines 928-994 (`updateUserSentiment`)
   - Modular: `AIManager.js` updateUserSentiment

---

## 🚀 **QUICK COMMAND REFERENCE**

### Start Original Bot:
```powershell
cd "C:\Users\markq\Ultimate bot project"
node hangfm-bot\hang-fm-bot.js
```

### Start Modular Bot:
```powershell
cd "C:\Users\markq\Ultimate bot project"
node hangfm-bot-modular\hang-fm-bot.js
```

---

**This map should help you identify ANY differences between the working original and the modular version!**

